﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MyRepository.Models;
using MyRepository.Models.Repositories;

namespace MyRepository.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly NewsRepository _newsRepository;
        private readonly UserRepository _userRepository;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            _newsRepository = new NewsRepository();
            _userRepository = new UserRepository();
        }

        public IActionResult Index()
        {
            ViewData["PVTitle"] = "This is a Partial View";
            ViewBag.VCTitle = "This is a View Component";
            //------------------------
            return View(_newsRepository.GetNewsList());
        }

        public IActionResult NewsDetail(int Id)
        {
            ViewBag.Id = Id;
            return View(_newsRepository.FindNewsDetail(Id));
        }
        
        public IActionResult NewsDetailViewComponent(int Id)
        {
            return ViewComponent("NewsDetail", new { id = Id });
        }
        public IActionResult News()
        {
            return View(_newsRepository.GetNews());
        }

        public IActionResult Create()
        {
            return View();
        }

        public IActionResult Users()
        {
            return View(_userRepository.GetUsers());
        }

        public IActionResult Details(int Id)
        {
            var user=_userRepository.GetUsers().Find(u => u.Id == Id);
            return View(user);
        }

        public IActionResult Edit(int Id)
        {
            var user = _userRepository.GetUsers().Find(u => u.Id == Id);
            return View(user);
        }

        public IActionResult Delete(int Id)
        {
            var user = _userRepository.GetUsers().Find(u => u.Id == Id);
            return View(user);
        }

        public JsonResult JsonNews()
        {
            return Json(_newsRepository.GetNews());
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
