﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MyRepository.Models.Repositories;

namespace MyRepository.ViewComponents
{
    public class NewsDetail: ViewComponent
    {
        private readonly NewsRepository _newsRepository;
        public NewsDetail()
        {
            _newsRepository = new NewsRepository();
        }
        public IViewComponentResult Invoke(int Id)
        {
            var news = _newsRepository.FindNewsDetail(Id);
            ViewBag.NewsId = Id;
            return View(viewName: "NewsDetail", news);
        }
    }
}
