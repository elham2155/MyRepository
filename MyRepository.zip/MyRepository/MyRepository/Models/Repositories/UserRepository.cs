﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MyRepository.Models.Entities;

namespace MyRepository.Models.Repositories
{
    public class UserRepository
    {
        private readonly List<Users> _users;
        public UserRepository()
        {
            _users = new List<Users>();
            _users.Add(new Users { Id = 1, Email = "Elham@gmail.com", Username = "elham", Password = "1234567", ConfirmPassword = "1234567" });
            _users.Add(new Users { Id = 2, Email = "Sam@gmail.com", Username = "sam", Password = "1234567", ConfirmPassword = "1234567" });
            _users.Add(new Users { Id = 3, Email = "Hamid@gmail.com", Username = "hamid", Password = "1234567", ConfirmPassword = "1234567" });
            _users.Add(new Users { Id = 4, Email = "Omid@gmail.com", Username = "omid", Password = "1234567", ConfirmPassword = "1234567" });
            _users.Add(new Users { Id = 5, Email = "Hamed@gmail.com", Username = "hamed", Password = "1234567", ConfirmPassword = "1234567" });

        }
        public List<Users> GetUsers()
        {
            return _users;
        }

    }
}
