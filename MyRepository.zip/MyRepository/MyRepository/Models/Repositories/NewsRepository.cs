﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MyRepository.Models.Entities;
using MyRepository.Models.ViewModels;

namespace MyRepository.Models.Repositories
{
    public class NewsRepository
    {
        private readonly List<News> _news;
        public NewsRepository()
        {
            _news = new List<News>();
            _news.Add(new News { Id = 1, Title = "Tecno Spark 8P Design, Features Leaked Online", Text = "Last month, Tecno announced the Spark 8. Now, the brand is expected to launch a new handset dubbed Spark 8P to its Spark series. The brand is yet to confirm the existence of the Spark 8P. In the latest development, renders of the Spark 8P have revealed its features and design. There is no word regarding the launch date or timeline of the upcoming Tecno Spark 8P.", Date = DateTime.Now, Author = "Eli" });
            _news.Add(new News { Id = 2, Title = "OnePlus 9RT Joint Edition With SD870 Launch Tipped", Text = "OnePlus 9RT is expected to launch on October 15; however, there is no official word regarding the launch. Now, the latest development suggests the handset will also get a special edition with the Snapdragon 870 SoC called OnePlus 9RT Joint Edition in China. For the unaware, the OnePlus 9RT will be the upgraded version of the OnePlus 9R.", Date = DateTime.Now, Author = "Sam" });
            _news.Add(new News { Id = 3, Title = "Realme Book Slim Selling With Up To Rs. 6,000 Discount", Text = "Realme Book Slim was launched back in August at starting price of Rs. 46,999 for the base model with Intel Core i3 processor with 8GB RAM and 256GB storage. The same model is now available at just Rs. 40,999 on Flipkart. The other variant that comes with Intel Core i5 chipset with 8GB RAM and 512GB storage is selling at Rs. 52,999", Date = DateTime.Now, Author = "Hamid" });
            _news.Add(new News { Id = 4, Title = "Windows 11 OS Review: A Visual Overhaul", Text = "Everything you need to know about Windows 11, the latest and greatest from Microsoft.", Date = DateTime.Now, Author = "Omid" });
            _news.Add(new News { Id = 5, Title = "Nokia T20 Tablet India Launch Expected Soon", Text = "Nokia is all set to launch a tablet dubbed the Nokia T20 on October 6 (tomorrow). Now, the India launch seems just around the corner as the table has received BIS certification. The exact launch date is yet to be revealed. The Nokia T20 tablet is expected to come in both Wi-Fi only and Wi-Fi + 4G variants. The tablet is likely to sport a 10.36-inch LCD panel.", Date = DateTime.Now, Author = "Hamed" });
        }
        public List<News> GetNews()
        {
            return _news;
        }
        
        public List<NewsListViewModel> GetNewsList()
        {
            List<NewsListViewModel> news = _news.Select(p => new NewsListViewModel {
                Id=p.Id, 
                Title=p.Title, 
                Date=p.Date
            }).ToList();
            return news;
        }
        public NewsDetailViewModel FindNewsDetail(int Id)
        {
            var detail = _news.Where(n=>n.Id==Id).FirstOrDefault();
            return new NewsDetailViewModel { 
                Title=detail.Title,
                Text=detail.Text,
                Author=detail.Author,
                Date=detail.Date
            };
        }
    }
}
