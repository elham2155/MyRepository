﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MyRepository.Models.Entities
{
    public class Users
    {
        [Required]
        public int Id { get; set; }

        [Required(ErrorMessage = "Please Enter your Email")]
        [EmailAddress]
        [MinLength(3)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please Enter Username")]
        [MaxLength(100)]
        [MinLength(3)]
        public string Username { get; set; }

        [Required(ErrorMessage = "Please Enter Password")]
        [MinLength(6)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Please Enter Confirmssword")]
        [Compare(nameof(Password), ErrorMessage = "Passwords don't match.")]
        public string ConfirmPassword { get; set; }

        public DateTime RegisteredDate { get; set; } = DateTime.Now;
        
    }
}
