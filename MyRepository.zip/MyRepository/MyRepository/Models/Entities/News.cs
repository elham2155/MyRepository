﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MyRepository.Models.Entities
{
    public class News
    {
        [Required]
        public int Id { get; set; }

        [Required(ErrorMessage ="Enter News' Title")]
        [MaxLength(100)]
        [MinLength(3)]
        public string Title { get; set; }

        [Required(ErrorMessage = "Enter News' Text")]
        [MinLength(3)]
        public string Text { get; set; }

        [RegularExpression("yyyy/mm/dd")]
        [Required(ErrorMessage = "Enter News' Date")]
        public DateTime Date { get; set; }
        public string Author { get; set; }
    }
}
